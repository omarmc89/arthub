<script setup>


</script>

<template>
    <h2>Llistat de llibres</h2>
</template>