<template>
  <svg version="1.1" viewBox="0 0 204.03 117.42" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
  <g transform="translate(-2.0595 .66243)" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="30.8">
    <text transform="matrix(1.0064 .0016342 -.0016553 .99361 0 0)" x="19.777185" y="113.25512" fill="#fc9797" font-family="'FiraCode Nerd Font'" font-size="89.945px" font-weight="bold" stroke="#bc1e3b" stroke-width="4.9291" style="paint-order:stroke fill markers" xml:space="preserve"><tspan x="19.777185" y="113.25512" fill="#fc9797" font-family="'FiraCode Nerd Font'" font-weight="bold" stroke="#bc1e3b" stroke-width="4.9291">HUB</tspan></text>
    <text transform="matrix(1.0075 .11704 -.11667 .97896 0 0)" x="11.703956" y="62.113316" fill="#bc1e3b" font-family="'Ink Free'" font-size="98.893px" stroke="#fc9797" stroke-width="2.5784" style="paint-order:stroke fill markers" xml:space="preserve"><tspan x="11.703956" y="62.113316" fill="#bc1e3b" font-size="98.893px" stroke="#fc9797" stroke-linejoin="round" stroke-width="2.5784" style="paint-order:stroke fill markers">ART</tspan></text>
  </g>
  </svg>
</template>